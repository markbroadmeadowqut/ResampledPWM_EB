/*
 * pwm.h
 *
 *  Created on: 05/08/2016
 *      Author: broadmea
 */

#ifndef PWM_H_
#define PWM_H_

void initPWM();
void pwmStart();
void pwmStop();

#endif /* PWM_H_ */
