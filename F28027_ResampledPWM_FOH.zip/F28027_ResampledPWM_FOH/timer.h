/*
 * timer.h
 *
 *  Created on: 22/05/2015
 *      Author: broadmea
 */

#ifndef TIMER_H_
#define TIMER_H_

void initTimer();

#endif /* TIMER_H_ */
